# Sudoku
Solving Sudokus using Backtracking Algorithm

# How to use
Add Sudoku grid to data.py (in Sudoku/src) and then import it to solver.py. Running solve method performs naive backtracking algorithm.

# TODO:
Currently checks grid from top to bottom, but performance could be improved by instead selecting the unlabelled cell with the fewest legal moves at any one time. 
